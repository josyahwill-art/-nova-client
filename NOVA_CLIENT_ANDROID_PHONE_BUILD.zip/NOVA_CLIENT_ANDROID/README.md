# NOVA CLIENT V2 — Android APK project

This is a small Android dashboard for NOVA CLIENT. It is not Minecraft itself and does not include Mojang/Microsoft game files or authentication. The Android Java launcher is installed separately.

## Build entirely from your phone

1. Download and extract this ZIP on your Android phone.
2. Create a GitHub account if you do not already have one.
3. In your mobile browser, create a **public or private** repository named `nova-client`.
4. Upload the extracted project files and folders, keeping their folder structure. Make sure `.github/workflows/android.yml` is included.
5. Open the repository's **Actions** tab. If prompted, enable Actions.
6. Select **Build NOVA CLIENT APK**, then tap **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open the completed run, scroll to **Artifacts**, and download `NOVA-CLIENT-APK`.
9. Extract the artifact ZIP. Tap `app-debug.apk` and follow Android's install prompt.

GitHub's mobile website may be easier to use in your browser's **Desktop site** mode. Do not share your GitHub password or Microsoft password with anyone.

## Minecraft Java

Install the official Amethyst Android launcher separately from:
https://github.com/AngelAuraMC/Amethyst-Android

Use its own official sign-in flow and follow its device compatibility guidance. You need a legitimate Minecraft: Java Edition account/license to play. Not every Java version or mod will perform well on every phone.

## Project files

- `app/src/main/java/com/nova/client/MainActivity.java` — NOVA dashboard
- `app/src/main/AndroidManifest.xml` — Android app declaration
- `app/build.gradle` — Android build configuration
- `.github/workflows/android.yml` — cloud APK build
