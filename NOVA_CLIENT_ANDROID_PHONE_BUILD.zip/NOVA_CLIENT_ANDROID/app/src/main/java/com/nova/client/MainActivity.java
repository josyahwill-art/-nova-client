package com.nova.client;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 13, 24);
    private final int panel = Color.rgb(18, 30, 50);
    private final int blue = Color.rgb(35, 145, 255);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(28), dp(20), dp(24));
        scroll.addView(page);

        TextView bolt = text("⚡", 48, blue, true);
        bolt.setGravity(Gravity.CENTER);
        page.addView(bolt);

        TextView title = text("NOVA CLIENT", 29, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView subtitle = text("JAVA EDITION • ANDROID", 13, blue, true);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        TextView status = text("YOUR MINECRAFT DASHBOARD", 14, Color.WHITE, true);
        status.setPadding(0, dp(28), 0, dp(10));
        page.addView(status);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(panel);
        page.addView(card);

        card.addView(text("Game profile", 18, Color.WHITE, true));
        card.addView(text("Minecraft: Java Edition", 15, Color.LTGRAY, false));
        card.addView(text("Version: Latest stable (choose inside your game launcher)", 13,
                Color.LTGRAY, false));

        Switch performance = new Switch(this);
        performance.setText("Performance-friendly profile reminder");
        performance.setTextColor(Color.WHITE);
        performance.setChecked(true);
        card.addView(performance);

        TextView note = text(
                "This app is a NOVA dashboard. It does not contain Minecraft or its game engine. " +
                "Use the separate Amethyst launcher to install and run Java Edition.",
                13, Color.LTGRAY, false);
        note.setPadding(0, dp(14), 0, dp(8));
        card.addView(note);

        addButton(page, "GET ANDROID JAVA LAUNCHER", () ->
                open("https://github.com/AngelAuraMC/Amethyst-Android"));
        addButton(page, "MINECRAFT OFFICIAL WEBSITE", () ->
                open("https://www.minecraft.net/"));
        addButton(page, "NOVA SETUP HELP", () ->
                open("https://github.com/AngelAuraMC/Amethyst-Android/wiki"));

        TextView footer = text("NOVA CLIENT V2 • COMMUNITY DASHBOARD", 11,
                Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(26), 0, 0);
        page.addView(footer);

        setContentView(scroll);
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        lp.topMargin = dp(12);
        parent.addView(button, lp);
        button.setOnClickListener(v -> action.run());
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private void open(String address) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(address)));
        } catch (Exception e) {
            Toast.makeText(this, "Could not open link", Toast.LENGTH_LONG).show();
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
